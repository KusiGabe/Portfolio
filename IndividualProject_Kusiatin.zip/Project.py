import pandas as pd 
from sklearn.pipeline import Pipeline
from sklearn.feature_extraction.text import CountVectorizer
from sklearn.model_selection import train_test_split
from sklearn.model_selection import cross_val_score
from sklearn.metrics import accuracy_score, f1_score 
from sklearn.metrics import plot_confusion_matrix
from sklearn.naive_bayes import MultinomialNB
import pickle
import streamlit as st
from wordcloud import WordCloud
import altair as alt
from PIL import Image
pd.set_option('display.max_columns', 50)

# opening ML pipeline (multinomialNB)
with open('pipeline.pkl', 'rb') as f:
         pipeline = pickle.load(f)

st.set_option('deprecation.showPyplotGlobalUse', False)
#Setting page title and icon
st.set_page_config(page_title="Perscription Drug Review Sentiment Analysis", layout= "centered", page_icon='pill')
home, model, about = st.tabs(["Home", "Model", "About"])

# Define the `model` variable outside the `model` tab block
predicted_test = None

with home:
    st.header('Sentiment Analysis Individual Project')
    st.subheader('Created by Gabriel Kusiatin, MANA 23')  
    '---'  
#Reading in csv and preprocessing data to be fed into pipeline
    df_test = pd.read_csv('test.csv')
    # Displaying processed dataframe
    st.subheader('Pre-processed Data Frame')
    st.dataframe(df_test.head(5))
    st.write('The dataset is comprised of 4 columns: benifits_review, side_effects_review, comments_review, rating. At this point, there is no column that indicates sentiment, however, the rating column does indicate how the person felt about the medication. Given this information, I decided I could use the rating column as the metric to create the sentiment column.')
    df1_test = df_test.copy()
    def combine(df1):
        df1['review'] = df1['benefits_review'] + " " + df1['side_effects_review'] + " " + df1['comments_review']
        df1['sentiment'] = df1.rating.apply(lambda x: 'positive' if x >= 6 else 'negative')
        df1 = df1.drop(['rating', 'benefits_review', 'side_effects_review', 'comments_review'], axis=1)
        return df1
    df1_test = combine(df1_test)
    #Creating a sidebar to filter and adjust home page
    st.sidebar.title("Filter Options")
    num_rows = st.sidebar.slider("Number of Rows", min_value=10, max_value=len(df1_test), value=50)
    "---"
    st.subheader('Drug Review Dataset: Post-processing')
    st.dataframe(df1_test.head(num_rows))
    st.write('Above is the cleaned version of the test.csv file used to test my machine learning model. The review column is the summation of all the comments pertaining to a certain drug, while the sentiment column is based on the rating column from the pre-cleaned dataset. Ratings were assinged in each record on a scale from 1-10, 1 being the worst and 10 being the best. In my analysis, I assigned ratings of 6 or higher as positive sentiment and eveything else as negative.')
    "---"
    st.header('Bar Chart visualizing number of negative vs positive reviews')
    # Count the sentiment values
    sentiment_counts = df1_test.sentiment.value_counts()
# Create a bar chart
    chart = alt.Chart(sentiment_counts.reset_index()).mark_bar().encode(
    x='index:N',
    y='sentiment:Q'
    )
# Set the chart title
    chart_title = f'Sentiment Counts ({len(df1_test)} reviews)'
# Display the chart and chart title
    st.altair_chart(chart, use_container_width=True)
    st.write(f'### {chart_title}')
    st.write('As seen in the bar chart, there are more than twice the number of positive reviews as there are negative reviews.')
    "---"
    #Creating WordCloud
    st.header('Word Cloud Visualization of Key Words')
    df_pos = df1_test.loc[df1_test.sentiment == "positive", ["review"]]
    df_neg = df1_test.loc[df1_test.sentiment == "negative", ["review"]]
    col1, col2 = st.columns(2)
    with col1:
        st.subheader("Positive Posts")
        st.image(WordCloud().generate("/n".join(list(df_pos.review))).to_image())
    with col2:
        st.subheader("Negative Posts")
        st.image(WordCloud().generate("/n".join(list(df_neg.review))).to_image())
    st.write('Above is a Word Cloud visualization that depicts the frequency of certain words in reviews that are either positive or negative in sentiment. The larger the word, the more frequently it appeared in those kinds of reviews.')

with model:
    st.header('Model Selected: MultinomialNB')
    st.subheader('Reason for selection')
    "---"
    st.write('I created 4 different machine learning pipelines to predict sentiment using the train.csv file. The 4 models I produced go as follows: Random Forest Classifier, Linear SVC, Logistic Regression, and Multinomial NB. ')
    "---"
#Creating dataframe with results from each of the models ran on the test.csv file   
    df = pd.DataFrame({
    'Model': ['Logistic Regression', 'RandomForest', 'LinearSVC', 'Multinomial'], 
    'Accuracy Score': [.703, .703, .704, .757], 
    'F1 Score': [.768, .764, .772, .815]
})
#Creating charts for accuracy and f1_score and doing some formating 
    chart_dict = {
        'Accuracy': alt.Chart(df).mark_bar(width=20).encode(
        x=alt.X('Accuracy Score:Q', axis=alt.Axis(format='%', tickCount=6)),
        y=alt.Y('Model:N', sort='-x'),
        tooltip=[alt.Tooltip('Accuracy Score:Q', format='.2%')]
    ),
        'F1 Score': alt.Chart(df).mark_bar(width=20).encode(
        x=alt.X('F1 Score:Q', axis=alt.Axis(format='%', tickCount=6)),
        y=alt.Y('Model:N', sort='-x'),
        tooltip=[alt.Tooltip('F1 Score:Q', format='.2%')]
    )
}
#Creating button that allows user to swtich between charts
    st.subheader('Model Comparison')
    chart_choice = st.radio("Select chart", ('Accuracy', 'F1 Score'))
    st.altair_chart(chart_dict[chart_choice])
    st.write('The interactive bar chart above shows the differences in accuracy and f1 score between the different models I created. As you can see, in both f1 score and accuracy, the multinomialNB model performed the best.')
    if predicted_test is None:
        predicted_test = pipeline.predict([doc for doc in df1_test.review])
    st.write('Accuracy and F1 score for MultinomialNB model:')
    st.write("Accuracy score:", accuracy_score(df1_test.sentiment, predicted_test))
    st.write("F1 score:", f1_score(df1_test.sentiment, predicted_test, pos_label='positive'))
    "---"
# Generate and display the confusion matrix
    st.header('Confusion Matrix')
    plot_confusion_matrix(pipeline, df1_test.review, df1_test.sentiment)
    st.pyplot()
    st.write('The confustion matrix is a table that is used to evaluate the performance of a classification model by comparing predicted and actual values. The matrix displays the number of true positive, false positive, true negative, and false negative values in relation to the actual and predicted classifications. As seen above, the model is incredibly accurate in predicting positive sentiment, however, it struggles in comparison in predicting negative sentiment. This could be because negative reviews may be more nuanced in terms of the language the review used, making it more difficult for the model to predict it as accuratly as positive reviews.')
    "---"
    pred_df = pd.DataFrame({
                        'review': df1_test.review,
                        'Predicted' : pipeline.predict([doc for doc in df1_test.review]), 
                        'Actual': df1_test.sentiment}) 
    neg_rev = pred_df.loc[(pred_df['Predicted'] == 'negative') & (pred_df['Actual'] == 'positive')]
    st.subheader('Predicted Negative but Actual was Positive... Why?')
    st.dataframe(neg_rev.head(10))
    st.write("In the example dataframe above, it's clear in some cases that the model was just simply wrong. In these cases, it seems as though the model misinterpreted the description of the symptoms as negative, when in reality, the individual was discussing the loss of those symptoms. In other cases, it seems as though someone would describe a medication as harmful or unable to completely eliminate the illness, and would still give the medication a rating of 6 or greater. In these instances, I do not think the model is to blame.")
    "---"
    st.subheader("Full Data Frame with all reviews, predicted, and actual columns")
    st.dataframe(pred_df)
    "---"
    st.subheader("Test My Model")
    user_input = st.text_input("Enter a review", "")
    if user_input:
    # Use the loaded pipeline to make a prediction
        predicted_sentiment = pipeline.predict([user_input])[0]
    # Display the predicted sentiment
        st.write("The predicted sentiment of the input text is:", predicted_sentiment)            
         
with about:
    st.header('About the Project') 
    "---"
    st.subheader('Project Design')
    st.write('This project was created as a part of the graduate-level Applied Machine Learning course within the Tulane University A.B. Freeman School of Business. Our class was tasked with developing an interactive streamlit application that interprets medication reviews and predicts whether the sentiment of said review is positive or negative.')
    "---"
    st.subheader('Graduate Student')
    st.write('I am Gabriel Kusiatin and I am currently a Masters of Business Analytics student at Tulane University. Currently looking for summer internship/employment oppurtunities in data science/analytics within the media and entertainment industry. If interested, contact me at gkusiatin@tulane.edu!')
    image = Image.open('TulaneBSchool.jpg')
    st.image(image, caption='Tulane A.B. Freeman School of Business')

            


